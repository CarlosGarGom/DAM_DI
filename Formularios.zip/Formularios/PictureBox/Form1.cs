using System;
namespace PictureBox
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            label1.Text= 
            string directorio = Directory.GetParent(System.IO.Directory.GetCurrentDirectory(););
        }
    }
}
