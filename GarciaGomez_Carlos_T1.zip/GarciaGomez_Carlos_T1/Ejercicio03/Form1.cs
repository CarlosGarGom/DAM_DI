using System.ComponentModel;

namespace Ejercicio03
{
    public partial class Form1 : Form
    {
        private BindingList<string> citasSource;

        public Form1()
        {
            InitializeComponent(); 

          
            citasSource = new BindingList<string>();
            lbCitas.DataSource = citasSource;

           
            Load += Form1_Load;

          
            bA�adir.Click += bA�adir_Click;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Rellenar las horas en el ComboBox
            for (int hour = 1; hour <= 12; hour++) // Horas de 1 a 12 (formato 12 horas)
            {
                cbHora.Items.Add($"{hour:D2}:00");
                cbHora.Items.Add($"{hour:D2}:30");
            }

            // Seleccionar el primer elemento como valor por defecto
            cbHora.SelectedIndex = 0;

            // Configuraci�n adicional
            mcCalendario.MinDate = DateTime.Today; // Evitar fechas anteriores a hoy
            mcCalendario.MaxSelectionCount = 1; // Seleccionar un dia solo
        }

        private void bA�adir_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbCitas.Text))
            {
                MessageBox.Show("El texto de la cita no puede estar vac�o.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Obtener los valores de los controles
            string hora = cbHora.SelectedItem?.ToString();
            if (hora == null)
            {
                MessageBox.Show("Por favor, selecciona una hora v�lida.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string amPm = rbAM.Checked ? "AM" : "PM";

            // Crear la descripci�n de la nueva cita
            string nuevaCita = $"{hora} {amPm} {tbCitas.Text}";

            // A�adir la cita al origen de datos
            citasSource.Add(nuevaCita);

            // Limpiar los campos para la siguiente entrada
            tbCitas.Clear();
            rbAM.Checked = true;
            cbHora.SelectedIndex = 0;
        }


        private void rbAM_CheckedChanged(object sender, EventArgs e)
        {
            // Este evento puede quedarse vac�o si no necesitas manejar cambios aqu�
        }

        private void bBorrar_Click_1(object sender, EventArgs e)
        {
            if (lbCitas.SelectedIndex == -1)
            {
                MessageBox.Show("Por favor, selecciona una cita para borrar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Convertir el elemento seleccionado a string y eliminarlo de la lista
            string citaSeleccionada = lbCitas.SelectedItem as string;
            if (citaSeleccionada != null)
            {
                citasSource.Remove(citaSeleccionada);
            }
        }

        private void bGuardar_Click(object sender, EventArgs e)
        {
           
        }

        private void bGuardar_Click_1(object sender, EventArgs e)
        {
            if (citasSource.Count == 0)
            {
                MessageBox.Show("No hay citas para guardar.", "Informaci�n", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Obtener la fecha seleccionada
            DateTime fechaSeleccionada = mcCalendario.SelectionRange.Start;
            string diaDelA�o = fechaSeleccionada.DayOfYear.ToString();
            string a�o = fechaSeleccionada.Year.ToString();

            // Crear el directorio si no existe
            string directorio = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, a�o);
            Directory.CreateDirectory(directorio);

            // Crear el archivo
            string rutaArchivo = Path.Combine(directorio, $"{diaDelA�o}.txt");
            File.WriteAllLines(rutaArchivo, citasSource.Cast<string>());

            
            MessageBox.Show($"Citas guardadas correctamente en:\n{rutaArchivo}", "Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
